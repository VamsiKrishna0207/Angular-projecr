export class PetData {
    id: number = 0;
    name: string = '';
    quantity: string = '';
    mobile: string = '';
    price: string = '';
    services: string = '';
}