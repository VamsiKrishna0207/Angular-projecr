import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offical-site',
  templateUrl: './offical-site.component.html',
  styleUrls: ['./offical-site.component.css']
})
export class OfficalSiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
