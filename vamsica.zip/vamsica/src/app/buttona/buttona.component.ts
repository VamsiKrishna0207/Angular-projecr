import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttona',
  templateUrl: './buttona.component.html',
  styleUrls: ['./buttona.component.css']
})
export class ButtonaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
